#!/bin/sh

# install 'automake' package 
#
# eventually run autoreconf when it will work better 
# autoreconf --force --install -I config 

# if necessary you may uncomment and update the following two environment variables: 
export CPPFLAGS="$CPPFLAGS -O3   " 

aclocal           
autoheader        
autoconf          
automake -a -c -f 
./configure       
# ./configure LDFLAGS=-static
make              
